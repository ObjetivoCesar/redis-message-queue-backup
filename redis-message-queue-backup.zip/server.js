const express = require('express');
const Redis = require('ioredis');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const fetch = require('node-fetch');
const logger = require('./src/utils/logger');

// Crear la aplicación Express
const app = express();
let server = null;

// Configuración de Redis
const redis = new Redis();

// Función para cerrar la aplicación gracefully
async function gracefulShutdown(signal) {
    logger.info(`${signal} recibido. Iniciando cierre graceful...`);
    
    if (server) {
        logger.info('Cerrando servidor HTTP...');
        server.close(() => {
            logger.info('Servidor HTTP cerrado.');
        });
    }

    try {
        logger.info('Cerrando conexión Redis...');
        await redis.quit();
        logger.info('Conexión Redis cerrada.');
    } catch (err) {
        logger.error('Error al cerrar Redis:', { error: err.message });
    }

    // Dar tiempo para que se completen las operaciones pendientes
    setTimeout(() => {
        logger.info('Proceso terminado.');
        process.exit(0);
    }, 1000);
}

// Manejar señales de terminación
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Configuración de Multer para manejo de archivos
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = 'uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // límite de 10MB
    },
    fileFilter: function (req, file, cb) {
        // Permitir solo imágenes y audio
        if (file.mimetype.startsWith('image/') || file.mimetype.startsWith('audio/')) {
            cb(null, true);
        } else {
            cb(new Error('Solo se permiten archivos de imagen y audio'));
        }
    }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Variable para rastrear el tiempo del primer mensaje por usuario
const userFirstMessageTime = new Map();

// Middleware de logging
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        logger.info('Petición procesada', {
            method: req.method,
            path: req.path,
            status: res.statusCode,
            duration: `${duration}ms`
        });
    });
    next();
});

// Ruta para recibir mensajes
app.post('/api/messages', upload.single('file'), async (req, res) => {
    try {
        const { user_id, message, timestamp } = req.body;
        
        // Validaciones básicas
        if (!user_id || !message) {
            return res.status(400).json({
                success: false,
                error: 'Se requieren user_id y message'
            });
        }

        logger.info('Mensaje recibido', { user_id, message, timestamp, file: req.file?.filename });
        
        // Registrar el tiempo del primer mensaje si no existe
        if (!userFirstMessageTime.has(user_id)) {
            userFirstMessageTime.set(user_id, Date.now());
            logger.info('Iniciando temporizador para usuario', { user_id });
        }
        
        // Crear una clave única para el mensaje
        const messageKey = `message:${user_id}:${Date.now()}`;
        
        // Preparar el mensaje con información del archivo si existe
        const messageData = {
            user_id,
            message,
            timestamp: timestamp || new Date().toISOString(),
            processed: false,
            bundled: false,
            first_message_time: userFirstMessageTime.get(user_id)
        };

        if (req.file) {
            messageData.file = {
                filename: req.file.filename,
                path: req.file.path,
                mimetype: req.file.mimetype,
                size: req.file.size
            };
        }
        
        // Almacenar el mensaje en Redis con expiración de 5 minutos
        await redis.setex(messageKey, 300, JSON.stringify(messageData));
        logger.info('Mensaje almacenado en Redis', { messageKey });
        
        res.status(200).json({
            success: true,
            message: "✓",
            key: messageKey
        });
    } catch (error) {
        logger.error('Error al procesar mensaje', { error: error.message, stack: error.stack });
        res.status(500).json({
            success: false,
            error: 'Error interno del servidor'
        });
    }
});

// Nueva ruta para verificar el estado de los mensajes
app.get('/api/messages/status', async (req, res) => {
    try {
        const { user_id } = req.query;
        if (!user_id) {
            return res.status(400).json({ error: 'Se requiere user_id' });
        }

        // Buscar mensajes del usuario
        const messageKeys = await redis.keys(`message:${user_id}:*`);
        const responseKeys = await redis.keys(`response:${user_id}:*`);
        let allProcessed = true;
        let makeResponse = null;
        let responseFound = false;

        // Verificar si hay mensajes sin procesar
        for (const key of messageKeys) {
            const messageData = await redis.get(key);
            if (messageData) {
                const message = JSON.parse(messageData);
                if (!message.processed) {
                    allProcessed = false;
                    break;
                }
            }
        }

        // Buscar SOLO la respuesta más reciente
        if (responseKeys.length > 0) {
            // Ordenar las claves por timestamp
            responseKeys.sort((a, b) => {
                const timestampA = parseInt(a.split(':').pop());
                const timestampB = parseInt(b.split(':').pop());
                return timestampB - timestampA;
            });

            // Tomar SOLO la respuesta más reciente
            const latestResponse = await redis.get(responseKeys[0]);
            if (latestResponse) {
                const responseData = JSON.parse(latestResponse);
                makeResponse = responseData.makeResponse;
                responseFound = true;
                
                // Eliminar la respuesta después de enviarla
                await redis.del(responseKeys[0]);
                logger.info(`🗑️ Respuesta eliminada después de enviarla: ${responseKeys[0]}`);
            }
        }

        res.json({
            processed: allProcessed,
            makeResponse: responseFound ? makeResponse : null
        });
    } catch (error) {
        console.error('Error al verificar estado:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

// Función para agrupar mensajes por usuario
async function createMessageBundles() {
    try {
        // Obtener todas las claves de mensajes no procesados
        const keys = await redis.keys('message:*');
        
        if (keys.length > 0) {
            logger.info(`🔍 Encontrados ${keys.length} mensajes para procesar`);
        }

        // Agrupar mensajes por usuario_id
        const messagesByUser = {};
        const currentTime = Date.now();
        
        // Primero, ordenar las claves por timestamp
        keys.sort((a, b) => {
            const timestampA = parseInt(a.split(':').pop());
            const timestampB = parseInt(b.split(':').pop());
            return timestampA - timestampB;
        });
        
        for (const key of keys) {
            const messageData = await redis.get(key);
            if (messageData) {
                const message = JSON.parse(messageData);
                if (!message.processed && !message.bundled) {
                    const userId = message.user_id;
                    const firstMessageTime = message.first_message_time;
                    const timeElapsed = currentTime - firstMessageTime;

                    // Solo procesar si han pasado 20 segundos desde el primer mensaje
                    if (timeElapsed >= 20000) {
                        if (!messagesByUser[userId]) {
                            messagesByUser[userId] = {
                                messages: [],
                                keys: [],
                                firstMessageTime: firstMessageTime
                            };
                            logger.info(`👤 Nuevo usuario ${userId} agregado al bundle`);
                        }
                        
                        // Marcar el mensaje como bundled antes de agregarlo
                        message.bundled = true;
                        await redis.setex(key, 300, JSON.stringify(message));
                        
                        messagesByUser[userId].messages.push({
                            message: message.message,
                            timestamp: message.timestamp,
                            file: message.file ? {
                                filename: message.file.filename,
                                path: `http://localhost:3001/uploads/${message.file.filename}`,
                                mimetype: message.file.mimetype,
                                size: message.file.size
                            } : null
                        });
                        messagesByUser[userId].keys.push(key);
                    } else {
                        logger.info(`⏳ Esperando ${((20000 - timeElapsed)/1000).toFixed(1)} segundos más para el usuario ${userId}`);
                    }
                }
            }
        }

        // Procesar los bundles que han cumplido el tiempo de espera
        for (const userId in messagesByUser) {
            if (messagesByUser[userId].messages.length > 0) {
                logger.info(`📦 Creando bundle para usuario ${userId} con ${messagesByUser[userId].messages.length} mensajes después de 20 segundos`);
                
                try {
                    const response = await fetch('https://hook.us2.make.com/vy46yk4a2c202wnyyma2n78v4id4hb2h', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            user_id: userId,
                            messages: messagesByUser[userId].messages,
                            bundle_size: messagesByUser[userId].messages.length,
                            timestamp: new Date().toISOString(),
                            total_wait_time: (Date.now() - messagesByUser[userId].firstMessageTime) / 1000
                        })
                    });

                    if (response.ok) {
                        logger.info(`✅ Bundle enviado exitosamente para usuario ${userId}`);
                        const makeResponse = await response.text();
                        logger.info(`📩 Respuesta de Make: ${makeResponse}`);
                        
                        // Verificar si ya existe una respuesta para este usuario
                        const existingResponseKeys = await redis.keys(`response:${userId}:*`);
                        if (existingResponseKeys.length > 0) {
                            // Eliminar respuestas anteriores
                            for (const key of existingResponseKeys) {
                                await redis.del(key);
                                logger.info(`🗑️ Respuesta anterior eliminada: ${key}`);
                            }
                        }
                        
                        // Almacenar UNA SOLA respuesta para todo el bundle
                        const responseKey = `response:${userId}:${Date.now()}`;
                        await redis.setex(responseKey, 300, JSON.stringify({
                            user_id: userId,
                            makeResponse: makeResponse,
                            timestamp: new Date().toISOString(),
                            bundle_size: messagesByUser[userId].messages.length
                        }));
                        logger.info(`💾 Respuesta almacenada en Redis con clave: ${responseKey}`);
                        
                        // Eliminar TODOS los mensajes del bundle de Redis inmediatamente
                        for (const key of messagesByUser[userId].keys) {
                            await redis.del(key);
                            logger.info(`🗑️ Mensaje eliminado de Redis: ${key}`);
                        }
                        // Limpiar el tiempo del primer mensaje para este usuario
                        userFirstMessageTime.delete(userId);
                        logger.info(`🧹 Tiempo de primer mensaje eliminado para usuario ${userId}`);
                    } else {
                        const errorText = await response.text();
                        logger.error(`⚠️ Error al enviar bundle para usuario ${userId}: ${errorText}`);
                        
                        // Si hay error, desmarcar los mensajes como bundled
                        for (const key of messagesByUser[userId].keys) {
                            const messageData = await redis.get(key);
                            if (messageData) {
                                const message = JSON.parse(messageData);
                                message.bundled = false;
                                await redis.setex(key, 300, JSON.stringify(message));
                            }
                        }
                    }
                } catch (error) {
                    logger.error(`❌ Error procesando bundle para usuario ${userId}:`, error);
                }
            }
        }
    } catch (error) {
        logger.error('❌ Error en createMessageBundles:', error);
    }
}

// Ejecutar el procesador de bundles cada 5 segundos
const BUNDLE_INTERVAL = 5000; // 5 segundos para revisar más frecuentemente
logger.info(`⚙️ Configurando procesador de bundles para ejecutarse cada ${BUNDLE_INTERVAL/1000} segundos`);
setInterval(createMessageBundles, BUNDLE_INTERVAL);

// Iniciar el servidor con manejo de errores mejorado
const PORT = process.env.PORT || 3001;

function startServer() {
    return new Promise((resolve, reject) => {
        server = app.listen(PORT, () => {
            logger.info(`�� Servidor ejecutándose en el puerto ${PORT}`);
            resolve(server);
        }).on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                logger.info(`⚠️ Puerto ${PORT} en uso, intentando cerrar el proceso existente...`);
                require('child_process').exec(`npx kill-port ${PORT}`, async (error) => {
                    if (error) {
                        logger.error('❌ Error al liberar el puerto:', error);
                        reject(error);
                        return;
                    }
                    logger.info(`✅ Puerto ${PORT} liberado, reiniciando servidor...`);
                    setTimeout(startServer, 1000);
                });
            } else {
                logger.error('❌ Error al iniciar el servidor:', err);
                reject(err);
            }
        });
    });
}

// Iniciar el servidor
startServer().catch(err => {
    logger.error('Error fatal al iniciar el servidor:', err);
    process.exit(1);
});